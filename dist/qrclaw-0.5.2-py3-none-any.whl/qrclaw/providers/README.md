# Google Vertex AI 测试记录

## 认证方式

- **类型**：Vertex AI Express API Key
- **项目 ID**：enhanced-voyage-491210-n9
- **区域**：us-central1
- **有效期**：90天

## 验证通过的模型

### 文本生成

| 模型 | 特点 |
|---|---|
| `gemini-2.5-pro` | 最强推理，适合复杂任务 |
| `gemini-2.5-flash` | 快速均衡（首个验证通过）|
| `gemini-2.5-flash-lite` | 最轻量，速度最快 |
| `gemini-3-flash-preview` | 新一代 Flash 预览版 |
| `gemini-3-pro-preview` | 新一代 Pro 预览版 |

### 图片生成

| 模型 | 文生图 | 图生图 | 特点 |
|---|---|---|---|
| `gemini-2.5-flash-image` | ✅ | ✅ | 稳定可用，支持中文提示词 |
| `gemini-3-pro-image-preview` | ✅ | ✅ | 新一代图片 Pro 预览版 |
| `gemini-3.1-flash-image-preview` | ✅ | ✅ | 新一代图片 Flash 预览版 |

## 验证失败的模型

| 模型 | 错误原因 |
|---|---|
| `gemini-2.0-flash-001` | 404 模型不存在 |
| `gemini-2.0-flash-lite-001` | 404 模型不存在 |
| `gemini-2.0-flash-preview-image-generation` | 404 模型不存在 |
| `gemini-2.0-flash-exp` | 404 模型不存在 |
| `gemini-2.0-flash-exp-image-generation` | 404 模型不存在 |

## 代码示例

### 文本生成

```python
import os
from google import genai
from google.genai.types import HttpOptions

os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"
os.environ["GOOGLE_CLOUD_PROJECT"] = "enhanced-voyage-491210-n9"
os.environ["GOOGLE_CLOUD_LOCATION"] = "us-central1"

client = genai.Client(
    http_options=HttpOptions(api_version="v1"),
    api_key="YOUR_API_KEY"
)

response = client.models.generate_content(
    model="gemini-3-pro-preview",
    contents="你的提示词",
)
print(response.text)
```

### 图片生成

```python
import os
from io import BytesIO
from google import genai
from google.genai.types import GenerateContentConfig, Modality
from PIL import Image

os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "True"
os.environ["GOOGLE_CLOUD_PROJECT"] = "enhanced-voyage-491210-n9"
os.environ["GOOGLE_CLOUD_LOCATION"] = "us-central1"

client = genai.Client(api_key="YOUR_API_KEY")

response = client.models.generate_content(
    model="gemini-2.5-flash-image",
    contents="你的提示词",
    config=GenerateContentConfig(
        response_modalities=[Modality.TEXT, Modality.IMAGE],
    ),
)

for part in response.candidates[0].content.parts:
    if part.text:
        print("文字回复:", part.text)
    elif part.inline_data:
        image = Image.open(BytesIO(part.inline_data.data))
        image.save("output_image.png")
```

## 依赖安装

```bash
pip install google-genai Pillow --break-system-packages
```
